/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

/**
 *.Verificar Par ou Ímpar: Escreva um programa em Java que solicite ao usuário que
digite um número inteiro. Em seguida, o programa deve verificar se o número é par
ou ímpar e exibir a mensagem correspondente na tela.}
* if-else

 * 
 */

import java.util.Scanner;
public class Mavenproject1 {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        System.out.print("Digite um numero inteiro: ");
        int numero = scan.nextInt();
        
        if (numero % 2 == 0) {
            System.out.println("O número é par.");
        } else {
            System.out.println("O número é ímpar.");
        }
        scan.close();
    }
}

