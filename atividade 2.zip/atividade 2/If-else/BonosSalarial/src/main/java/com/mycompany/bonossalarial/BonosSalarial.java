/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bonossalarial;

/**
 *
 *Cálculo de Bônus Salarial: Escreva um programa em Java que solicita ao usuário
que digite o valor do salário mensal. O programa deve calcular o bônus salarial de
acordo com a seguinte regra: se o salário for menor ou igual a R$ 1000, o bônus
será de 10% do salário; caso contrário, o bônus será de 5% do salário. Em
seguida, exiba o valor do bônus na tela.

 */
import java.util.Scanner;
public class BonosSalarial {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        System.out.print("Digite o valor mensal do seu salario: ");
        double salario = scan.nextDouble();
        double bonus;
        
        if (salario <= 1000 ){
            bonus = salario * 0.10;
        } else { 
            bonus = salario * 0.05; 
        }  
        double salarioTotal = salario + bonus; 
        
        System.out.println("seu salario com o bonus e de: " + salarioTotal);
       
        scan.close();
    }
}
