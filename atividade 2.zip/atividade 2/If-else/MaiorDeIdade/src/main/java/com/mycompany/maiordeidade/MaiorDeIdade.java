/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.maiordeidade;

/**
 *
 * Verificar Maior de Idade: Escreva um programa em Java que peça ao usuário que
digite sua idade. Em seguida, o programa deve verificar se a idade é maior ou
igual a 18 anos e exibir a mensagem "Você é maior de idade" caso a condição seja
verdadeira, ou "Você é menor de idade" caso contrário.
 */
import java.util.Scanner;
public class MaiorDeIdade {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.print("Digite sua idade: " );
        int idade = scan.nextInt();
        if(idade >= 18){
            System.out.println("Voce e maior de idade");
        } else {
         System.out.println("Voce e menor de idade");   
        }
        scan.close();
    }
}
