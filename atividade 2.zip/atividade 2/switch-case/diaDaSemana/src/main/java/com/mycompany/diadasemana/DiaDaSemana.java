/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.diadasemana;

/**
 *
 * Verificar Dia da Semana: Escreva um programa em Java que solicite ao usuário
que digite um número de 1 a 7, representando os dias da semana. O programa
deve utilizar a estrutura de decisão switch-case para verificar o número digitado e
exibir na tela o dia da semana correspondente.

 */

import java.util.Scanner;
public class DiaDaSemana {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        System.out.print("Digite um numero de 1 a 7: ");
        int numero = scan.nextInt();
        
        switch(numero) {
            case 1: 
                System.out.println("Domingo");
                break;
                
            case 2:
                System.out.println("Segunda");
                break;
                
            case 3: 
                System.out.println("Terca");
                break;
                
            case 4: 
                System.out.println("Quarta");
                break;
                
            case 5: 
                System.out.println("Quinta");
                break;
                
            case 6: 
                System.out.println("Sexta");
                break;
                
            case 7:     
                System.out.println("Sabado");
                break;
                
            default: 
                System.out.println("Numero invalido, digite um numero entre 1 e 7");
                break;
        }
        scan.close();
    }
}
