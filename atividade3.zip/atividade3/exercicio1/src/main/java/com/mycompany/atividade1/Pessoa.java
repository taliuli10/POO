/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atividade1;

/**
 *
 *1) Crie uma classe Pessoa com atributo Nome e Idade

Solicite ao usuário essas informações de um grupo de 5 pessoas.

Pegue as informações via Scanner

Após o término da entrada, apresente:

a média das idades,

a maior idade,

a menor idade,

a quantidade de pessoas maior de idade.
 */
public class Pessoa {
    String nome;
    int idade;
    
    
    public Pessoa(){
    }
    
    public String getNome(){
        return nome;
    }
    
    public int getIdade(){
        return idade;
    }
}
