/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividade1;

import java.util.Scanner;

/**
 *
 * 1) Crie uma classe Pessoa com atributo Nome e Idade

Solicite ao usuário essas informações de um grupo de 5 pessoas.

Pegue as informações via Scanner
a
*
Após o término da entrada, apresente:

a média das idades,

a maior idade,

a menor idade,

a quantidade de pessoas maior de idade.
 */
public class Atividade1 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        Pessoa pessoa1 = new Pessoa();
        Pessoa pessoa2 = new Pessoa();
        Pessoa pessoa3 = new Pessoa();
        Pessoa pessoa4 = new Pessoa(); 
        Pessoa pessoa5 = new Pessoa();
        
        System.out.println("Digite o nome e idade das pessoas");
        //pessoa 1
        System.out.println("Digite o nome da pessoa 1: ");
        pessoa1.nome = scanner.nextLine();
        System.out.println("Digite a idade da pessoa 1: ");
        pessoa1.idade = scanner.nextInt();
        scanner.nextLine(); 
        //pessoa 2 
        System.out.println("Digite o nome da pessoa 2:");
        pessoa2.nome = scanner.nextLine();
        System.out.println("Digite a idade da pessoa 2:");
        pessoa2.idade = scanner.nextInt();
        scanner.nextLine();  
        //pessoa 3
        System.out.println("Digite o nome da pessoa 3:");
        pessoa3.nome = scanner.nextLine();
        System.out.println("Digite a idade da pessoa 3:");
        pessoa3.idade = scanner.nextInt();
        scanner.nextLine();
        //pessoa 4
        System.out.println("Digite o nome da pessoa 4:");
        pessoa4.nome = scanner.nextLine();
        System.out.println("Digite a idade da pessoa 4:");
        pessoa4.idade = scanner.nextInt();
        scanner.nextLine();
        //pessoa 5
        System.out.println("Digite o nome da pessoa 5:");
        pessoa5.nome = scanner.nextLine();
        System.out.println("Digite a idade da pessoa 5:");
        pessoa5.idade = scanner.nextInt();
        scanner.nextLine();
        
        
        int somaIdades = pessoa1.idade + pessoa2.idade + pessoa3.idade + pessoa4.idade + pessoa5.idade;
        
        int maiorIdade = pessoa1.idade;
        
        if (pessoa2.idade > maiorIdade) maiorIdade = pessoa2.idade;
        if (pessoa3.idade > maiorIdade) maiorIdade = pessoa3.idade;
        if (pessoa4.idade > maiorIdade) maiorIdade = pessoa4.idade;
        if (pessoa5.idade > maiorIdade) maiorIdade = pessoa5.idade;
        int menorIdade = pessoa1.idade;
        if (pessoa2.idade < menorIdade) menorIdade = pessoa2.idade;
        if (pessoa3.idade < menorIdade) menorIdade = pessoa3.idade;
        if (pessoa4.idade < menorIdade) menorIdade = pessoa4.idade;
        if (pessoa5.idade < menorIdade) menorIdade = pessoa5.idade;
        
        int maioresDeIdade = 0;
        if (pessoa1.idade >= 18) maioresDeIdade++;
        if (pessoa2.idade >= 18) maioresDeIdade++;
        if (pessoa3.idade >= 18) maioresDeIdade++;
        if (pessoa4.idade >= 18) maioresDeIdade++;
        if (pessoa5.idade >= 18) maioresDeIdade++;
        
        double mediaIdades = somaIdades / 5.0;

        System.out.println("\n--- Resultados ---");
        System.out.printf("Média das idades: %.2f\n", mediaIdades);
        System.out.println("Maior idade: " + maiorIdade);
        System.out.println("Menor idade: " + menorIdade);
        System.out.println("Quantidade de pessoas maiores de idade: " + maioresDeIdade);

        scanner.close();
    }
}
