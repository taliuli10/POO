/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercicio2;

/**
 *
 * 2) Crie e implemente uma classe PopulacaoBaratas que simule o crescimento de uma população de baratas.

O tamanho inicial da população de baratas é definido de forma Randômica. (pesquise o objeto Random...)

O método aumentaBaratas, simula a proporção que a população de baratas vai se multiplicar.

O método spray pulveriza as baratas com um inseticida e reduz a população em 10%.

O método getNumeroBaratas devolve o número atual de baratas.

Implemente também uma classe que simule uma cozinha que tenha uma população de baratas

Utilize a aumentaBaratas, utilize o spray, e imprima a contagem de baratas.
 */
public class Exercicio2 {

    public static void main(String[] args) {
        System.out.println("Populacao de baratas:");
        PopulacaoBaratas populacaoGeral = new PopulacaoBaratas();
        System.out.println("População geral inicial: " + populacaoGeral.getNumeroBarata());

        populacaoGeral.aumentaBaratas(0.3);
        System.out.println("Após aumento, população geral: " + populacaoGeral.getNumeroBarata());

        populacaoGeral.spray();
        System.out.println("Após spray, população geral: " + populacaoGeral.getNumeroBarata()+ "\n");

        
        System.out.println("Populacao de baratas na cozinha:");
        Cozinha cozinha = new Cozinha();
        cozinha.simular();
    }
}
