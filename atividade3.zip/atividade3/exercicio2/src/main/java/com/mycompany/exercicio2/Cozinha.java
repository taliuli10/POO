/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio2;

/**
 *
 * @author alunolab10
 */
public class Cozinha {
    PopulacaoBaratas populacao;

    public Cozinha() {
        populacao = new PopulacaoBaratas();
    }

    public void simular() {
        System.out.println("População inicial de baratas: " + populacao.getNumeroBarata());

        // Aumenta baratas (por exemplo, 50% de crescimento)
        populacao.aumentaBaratas(0.5);
        System.out.println("Após aumento, população: " + populacao.getNumeroBarata());

        // Pulveriza com spray
        populacao.spray();
        System.out.println("Após pulverização com spray, população: " + populacao.getNumeroBarata());
    }
}
