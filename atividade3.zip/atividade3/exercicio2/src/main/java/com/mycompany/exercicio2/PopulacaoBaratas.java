/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio2;

/**
 *
 * 2) Crie e implemente uma classe PopulacaoBaratas que simule o crescimento de uma população de baratas.

O tamanho inicial da população de baratas é definido de forma Randômica. (pesquise o objeto Random...)

O método aumentaBaratas, simula a proporção que a população de baratas vai se multiplicar.

O método spray pulveriza as baratas com um inseticida e reduz a população em 10%.

O método getNumeroBaratas devolve o número atual de baratas.

Implemente também uma classe que simule uma cozinha que tenha uma população de baratas

Utilize a aumentaBaratas, utilize o spray, e imprima a contagem de baratas.
 */

import java.util.Random;

public class PopulacaoBaratas {
    int numeroBarata;
    
    public PopulacaoBaratas(){
        Random random = new Random();
        this.numeroBarata = 50 + random.nextInt(51);
    }
    
    public void aumentaBaratas(double proporcao){
        int aumento = (int) (numeroBarata * proporcao);
        numeroBarata += aumento;
    }
    
    public void spray(){
        int reducao = (int) (numeroBarata * 0.1);
        numeroBarata -= reducao;
        if(numeroBarata < 0){
            numeroBarata = 0;
        }
        
    }
    
    public int getNumeroBarata(){
        return numeroBarata;
    }
}    
    



