/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author alunolab10
 */
class Pessoa {
    private String nome;
    private int idade;
    private String cidade;
    
    public Pessoa(String nome, int idade, String cidade){
        this.nome = nome;
        this.idade = idade;
        this.cidade = cidade;
    }
    
    public void exibirInformacoes(){
        System.out.println("nome: " + nome);
        System.out.println("idade: " + idade);
        System.out.println("cidade: " + cidade);
    }
    
    public void alterarCidade(String novaCidade){
        this.cidade = novaCidade;
    }
}
