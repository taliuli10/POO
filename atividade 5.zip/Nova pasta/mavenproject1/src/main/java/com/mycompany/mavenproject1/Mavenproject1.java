/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

/**
 *
 * @author alunolab10
 */
public class Mavenproject1 {

    public static void main(String[] args) {
        Pessoa pessoa1 = new Pessoa("Ricardo", 20, "Vitoria");
        Pessoa pessoa2 = new Pessoa("Yves", 19, "Vila-Velha");
        Pessoa pessoa3 = new Pessoa("Davi", 18, "Vitoria");
        
        pessoa1.exibirInformacoes();
        pessoa2.exibirInformacoes();
        pessoa3.exibirInformacoes();
        
        pessoa1.alterarCidade("vila-velha");
        pessoa1.exibirInformacoes();
    }
}
