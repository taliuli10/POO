/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.banco;

/**
 *
 * @author alunolab10
 */
public class Banco {

    public static void main(String[] args) {
        ContaBancaria conta1 = new ContaBancaria("João", 0, 12345);
        ContaBancaria conta2 = new ContaBancaria("Maria", 0, 67890);

 
        conta1.exibirSaldo();
        conta2.exibirSaldo();

      
        conta1.depositar(1000);
        conta2.depositar(500);

       
        conta1.exibirSaldo();
        conta2.exibirSaldo();

        conta1.sacar(200);

        conta1.exibirSaldo();

        conta1.transferir(300, conta2);

        conta1.exibirSaldo();
        conta2.exibirSaldo();
    }
}
