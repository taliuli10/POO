/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banco;

/**
 *
 * @author alunolab10
 */
public class ContaBancaria {
   private String titular;
   private double saldo;
   private int numero;
   
   public ContaBancaria(String titular, double saldo, int numero){
       this.titular = titular;
       this.saldo = 0.0;
       this.numero = numero;
   }
   
   public void depositar(double valor){
       if(valor > 0){
           saldo += valor;
           System.out.println("deposito de: " + valor + "realizado com sucesso");
       }else{
           System.out.println("valor de deposito invalido");
       }
   }
   
   public void sacar(double valor){
       if(valor > 0){
           if(valor <= saldo){
               saldo -= valor;
               System.out.println("saque de: " + valor + "realizado com sucesso");
           }else {
               System.out.println("saldo insuficiente ");
           }
       }else {
           System.out.println("valor invalido");
       }
   }
   
     public void exibirSaldo() {
        System.out.println("Saldo da conta de " + titular + " (Número: " + numero + "):  R$ " + saldo);
    }
     
     public void transferir(double valor, ContaBancaria contaDestino) {
        if (valor > 0 && valor <= saldo) {
            sacar(valor);  
            contaDestino.depositar(valor); 
            System.out.println("Transferência de R$ " + valor + " realizada com sucesso para a conta de " + contaDestino.titular);
        } else {
            System.out.println("Transferência não realizada. Verifique o valor e o saldo.");
        }
    }
     
}